from droid import *
from room import *
from items import *
from person import *
from bag import *
import config

print('Welcome to my Star Wars text based game!')
print('To get started, there are a few commands that you can enter:')
print("You can traverse the area by typing 'north', 'south', 'east', or 'west'")
print("If there is a character in a room, you can talk with them by 'talk'")
print("You can search the room you are in by typing 'search'")
print("You can then grab the items in the room by typing 'grab'")
print("You can look at the items in your bag by typing 'bag'\n")
print('You awaken..')

# Initialize the game


room1 = Room('the sleeping quarters', config.hilt, c3p0)
room2 = Room('a long, lateral hallway', None, None)
room3 = Room('the armory', blaster, None)
room4 = Room('the droid bay', spanner, r2d2)
room5 = Room('the middle of a long, lateral hallway', None, None)
room6 = Room('a long, lateral hallway', None, None)
room7 = Room('the meditation chamber', config.crystal, obi_wan)
room8 = Room('the hangar bay', config.energy_beam, None)
room9 = Room('in an ominously eerie room.\nA dark figure looms before you..*muffled breathing*', None, darth_vader)

room1.set_east(room2)
room2.set_north(room3)
room3.set_south(room2)
room2.set_south(room4)
room4.set_north(room2)
room2.set_west(room1)
room2.set_east(room5)
room5.set_west(room2)
room5.set_east(room6)
room6.set_west(room5)
room6.set_north(room7)
room6.set_south(room8)
room7.set_south(room6)
room8.set_north(room6)
room6.set_east(room9)
room9.set_west(room6)

room = room1
player_bag = Bag()

while True:
    print('You are in ' + room.name)
    print('What will you do?')
    command = input()
    if command == 'exit':
        break
    elif command == 'north':
        new_room = room.get_north()
    elif command == 'south':
        new_room = room.get_south()
    elif command == 'west':
        new_room = room.get_west()
    elif command == 'east':
        new_room = room.get_east()
    elif command == 'attack':
        if room.get_person() is not None:
            room.get_person().attack(player_bag)
            if room.get_person().ending:
                break
        else:
            print('There is no one here to attack.')
    elif command == 'search':
        if room.get_item() is not None or room.get_person() is not None:
            print('In the room, you see: ')
        else:
            print('There is nothing here.')
        if room.get_item() is not None:
            print(room.get_item_name())
        if room.get_person() is not None:
            print((room.get_person_name()))
        continue
    elif command == 'bag':
        print("Your bag contains: ")
        player_bag.inventory()
        continue
    elif command == 'talk':
        if room.get_person():
            print(room.person.name)
            print('Says: ')
            room.get_person().talk(player_bag)
            continue
    elif command == 'grab':
        if room.item:
            print('You grabbed the ' + str(room.get_item_name()))
            player_bag.append(room.grab_item())
        else:
            print('There is nothing here.')
        continue
    else:
        print('I do not know what ' + command + ' means')
        continue
    if new_room is None:
        print('You cannot go there')
        continue

    room = new_room
