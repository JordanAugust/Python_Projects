from items import *


hilt = Hilt('hilt')
energy_beam = EnergyBeam('energy beam')
crystal = Crystal('crystal')
lightsaber = Lightsaber('lightsaber')
