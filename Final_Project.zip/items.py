import random


class Items:

    def __init__(self, name):
        self.name = name
        self.items = []

    def get_name(self):
        return self.name


#  make subclasses for items that do particular things when you use them

class Blaster(Items):

    def use(self):
        print('You fire the blaster!')
        damage = random.randint(0, 2)
        print(damage)


class Lightsaber(Items):

    def use(self):
        return self.name


class Crystal(Items):

    def use(self):
        self.items.append(self.name)
        return self.name


class EnergyBeam(Items):

    def use(self):
        print('This is used to create a lightsaber')


class Hilt(Items):

    def use(self):
        self.items.append(self.name)
        return self.name


class Spanner(Items):

    def use(self):
        print('This spanner may be useful later...')


spanner = Spanner('spanner')

blaster = Blaster('blaster')

item1 = Items('crystal')
item2 = Items('blaster')
item3 = Items('energy beam')
item4 = Items('hilt')
item5 = Items('spanner')
