from items import *
import config


class Bag:

    def __init__(self):
        self.internal_items = []

    def has_item(self, item):
        for i in range(len(self.internal_items)):
            if self.internal_items[i] == item:
                return True
        return False

    def has_crystal(self):
        return self.has_item(config.crystal)

    def has_hilt(self):
        return self.has_item(config.hilt)

    def has_energy_beam(self):
        return self.has_item(config.energy_beam)

    def has_spanner(self):
        return self.has_item(config.spanner)

    def has_lightsaber(self):
        return self.has_item(config.lightsaber)

    def has_blaster(self):
        return self.has_item(config.blaster)

    def append(self, item):
        self.internal_items.append(item)

    def inventory(self):
        for i in range(len(self.internal_items)):
            print(self.internal_items[i].get_name())
