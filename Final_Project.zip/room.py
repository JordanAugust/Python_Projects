from items import *


class Room:

    def __init__(self, name, item, person):
        self.name = name
        self.north = None
        self.south = None
        self.east = None
        self.west = None
        self.item = item
        self.person = person

    def set_north(self, room):
        self.north = room

    def set_south(self, room):
        self.south = room

    def set_east(self, room):
        self.east = room

    def set_west(self, room):
        self.west = room

    """Checking if there is player can move to new room"""

    def get_north(self):
        return self.north

    def get_south(self):
        return self.south

    def get_east(self):
        return self.east

    def get_west(self):
        return self.west

    def get_item(self):
        return self.item

    def get_item_name(self):
        if self.item:
            return self.item.name  # need to return the item that is in the room

    def grab_item(self):
        if self.item:
            temp = self.item
            self.item = None
            return temp
        else:
            print('there is nothing here.')

    def get_person(self):
        return self.person

    def get_person_name(self):
        if self.name:
            return self.person.name
        else:
            pass
