from items import *
import config
import random


class Person:

    def __init__(self, name, health):
        self.name = name
        self.health = health


class C3P0(Person):

    def talk(self, bag):
        print('I understand the binary language of moisture vaporators')

    def attack(self, bag):
        print('You erroneously attempt to attack C3P0.')
        print('You lose')
        return False

    def ending(self, bag):
        print('this is as bug')


class R2D2(Person):

    def talk(self, bag):
        print('beep boop beep boop')

    def attack(self, bag):
        print("As you try to attack R2D2, an electrical shock arm emerges from R2D2's head.")
        print('You take ' + str(random.randint(20, 50)) + ' electric damage.')
        print('You lose')

    def ending(self, bag):
        print('this is a bug')


r2d2 = R2D2('R2D2', 5)
c3p0 = C3P0('C3P0', 5)


class ObiWan(Person):

    def talk(self, bag):
        if bag.has_crystal() and bag.has_hilt() and bag.has_energy_beam():
            if not bag.has_lightsaber():
                print("You may not have known him, but this belonged to your father..")
                print("You are now become powerful enough to face your deepest fear.")
                print('May the Force be with you, young jedi knight.')
                print('*You received the lightsaber*')
                bag.append(config.lightsaber)
            else:
                print('The Force is with you..')
        else:
            print("Obi Wan... That's a name I haven't heard in a long time..")

    def attack(self, bag):
        print('I felt a disturbance in the Force')

    def ending(self, bag):
        print('this is a bug')


class DarthVader(Person):

    def talk(self, bag):
        print("I've waited long for this moment.")
        print('I am the embodiment of Evil.')
        print('Light cannot pass through the Void.')
        print('I have succumbed to the Dark side.')
        print('However, there is still hope for you..')

    def attack(self, bag):
        if bag.has_lightsaber():
            print('Your lightsaber softly hums.')
            print('*A sharp swing!*')
            print('Streaks of green collide with flurries of red.')
            print("Obi Wan's words whirl in your mind.")
            print("'..This is your destiny..'")
            print('With a final blow, you fatally strike Darth Vader!..')
            print("'You were right about me..' he says with a hoarse voice.")
            print("..I will always be with you..")
        else:
            print('A fatal swing, glowing red with hatred, strikes you in the heart.')
            print('You have been defeated.')
            return False

    def ending(self, bag):
        if bag.has_lightsaber():
            return True


obi_wan = ObiWan('Obi Wan', 5)
darth_vader = DarthVader('Darth Vader', 10)
