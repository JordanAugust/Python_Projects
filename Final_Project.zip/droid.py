# class Droid:
#
#     def __init__(self, name):
#         self.name = name
#
#     def talk(self):
#         print('beep boop')
#
#
# class C3P0(Droid):
#
#     def talk(self):
#         print('I understand the binary language of moisture vaporators')
#
#
# class R2D2(Droid):
#
#     def talk(self):
#         print('beep boop beep boop')
#
#
# r2d2 = R2D2('R2D2')
# c3p0 = C3P0('C3P0')

